"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { selectResultDocument } from "../lib/result-view.mjs";

type Project = {
  id: string;
  name: string;
  business: string;
  users: string;
  stage: string;
  scope: string;
  constraints: string;
  unknowns: string;
};
type Doc = {
  id: string;
  title: string;
  body: string;
  task: string;
  sources: string;
  clarification?: string;
  version: number;
  createdAt: string;
  demo?: boolean;
  edited?: boolean;
  imported?: boolean;
  model?: string;
  elapsed?: number;
  usage?: { total_tokens: number };
  snapshot?: Partial<Project>;
  warnings?: string[];
  evidence: Record<string, string[]>;
};
type Run = {
  id: string;
  task: string;
  sources: string;
  clarification?: string;
  status: string;
  error?: string;
  documentId?: string;
  createdAt: string;
  questions?: string[];
};
type Draft = {
  task: string;
  sources: string;
  clarification: string;
  questions: string[];
};
const blank: Omit<Project, "id"> = {
  name: "",
  business: "",
  users: "",
  stage: "需求分析",
  scope: "",
  constraints: "",
  unknowns: "",
};
const newDraft = (): Draft => ({
  task: "",
  sources: "",
  clarification: "",
  questions: [],
});
const labels: Record<string, string> = {
  name: "项目名称",
  business: "业务对象",
  users: "目标用户",
  stage: "当前阶段",
  scope: "已确认范围",
  constraints: "关键约束",
  unknowns: "待确认事项",
};
const evidenceLabels: Record<string, string> = {
  facts: "用户提供的事实",
  sources: "资料支持",
  suggestions: "分析建议",
  assumptions: "待验证假设",
  risks: "风险与人工确认点",
};
const runLabels: Record<string, string> = {
  running: "正在生成",
  completed: "已完成",
  needs_input: "需要补充",
  failed: "运行失败",
  cancelled: "已取消",
};
const examples = [
  {
    name: "售后流程",
    text: "请分析电商售后申请流程的 MVP 需求。面向消费者和客服，第一版支持提交申请、查看处理状态和人工审核，不自动退款。请给出优先级、异常处理和逐功能验收标准。",
  },
  {
    name: "AI 客服",
    text: "请基于本项目背景分析 AI 客服 MVP。重点区分商品咨询、订单只读查询与人工接管，明确哪些环节需要 AI、哪些应使用确定性规则。不要编造业务量或效果。",
  },
  {
    name: "订单查询",
    text: "请分析订单状态查询需求：消费者通过已验证身份查询本人订单，客服在授权范围内协助查询。第一版只读，需覆盖订单不存在、无权限、上游超时和转人工。",
  },
  {
    name: "我的产品想法",
    text: "我想做一个面向刚毕业大学生的 AI 求职资料整理工具，把用户主动提供的岗位描述与个人经历整理为投递准备清单。第一版不自动投递、不编造经历。请分析核心需求与 MVP 边界。",
  },
];
function Icon({ name }: { name: string }) {
  const paths: Record<string, React.ReactNode> = {
    plus: <path d="M12 5v14M5 12h14" />,
    folder: <path d="M3 7V5h6l2 2h10v13H3V7Z" />,
    file: (
      <>
        <path d="M6 3h8l4 4v14H6zM14 3v5h4M9 12h6M9 16h6" />
      </>
    ),
    search: (
      <>
        <circle cx="10" cy="10" r="6" />
        <path d="m15 15 5 5" />
      </>
    ),
    settings: (
      <>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2" />
      </>
    ),
    arrow: <path d="M4 12h15m-6-6 6 6-6 6" />,
    close: <path d="m6 6 12 12M6 18 18 6" />,
    check: <path d="m5 12 4 4L19 6" />,
    menu: <path d="M4 6h16M4 12h16M4 18h16" />,
    download: <path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5" />,
    copy: (
      <>
        <rect x="8" y="8" width="12" height="13" rx="2" />
        <path d="M16 8V3H3v13h5" />
      </>
    ),
    book: (
      <>
        <path d="M12 5c-3-2-7-2-10 0v15c3-2 7-2 10 0 3-2 7-2 10 0V5c-3-2-7-2-10 0Zm0 0v15" />
      </>
    ),
    spark: (
      <>
        <path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z" />
      </>
    ),
  };
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name] || paths.file}
    </svg>
  );
}
async function api(path: string, method = "GET", body?: unknown) {
  let response;
  try {
    response = await fetch("/api/" + path, {
      method,
      headers:
        body !== undefined ? { "Content-Type": "application/json" } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw Error("网络连接中断，请检查连接后重试");
  }
  let data;
  try {
    data = await response.json();
  } catch {
    throw Error("服务暂时无法响应，请稍后重试");
  }
  if (!response.ok) throw Error(data.error || "操作失败");
  return data;
}
function download(
  name: string,
  data: string,
  type = "text/markdown;charset=utf-8",
) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name.replace(/[\\/:*?"<>|]/g, "-");
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function fmt(date: string) {
  return new Date(date).toLocaleString("zh-CN", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
function Modal({
  title,
  children,
  close,
}: {
  title: string;
  children: React.ReactNode;
  close: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const old = document.activeElement as HTMLElement;
    ref.current?.focus();
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "Tab") {
        const elements = ref.current?.querySelectorAll<HTMLElement>(
          'button,input,textarea,select,[tabindex="0"]',
        );
        if (!elements?.length) return;
        const first = elements[0],
          last = elements[elements.length - 1];
        if (
          e.shiftKey &&
          (document.activeElement === first ||
            document.activeElement === ref.current)
        ) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", handler);
    return () => {
      document.removeEventListener("keydown", handler);
      old?.focus();
    };
  }, [close]);
  return (
    <div className="overlay">
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        ref={ref}
      >
        <div className="modal-head">
          <h2>{title}</h2>
          <button className="icon-btn" onClick={close} aria-label="关闭">
            <Icon name="close" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
export default function Workspace() {
  const [ready, setReady] = useState(false),
    [auth, setAuth] = useState(false),
    [password, setPassword] = useState(""),
    [projects, setProjects] = useState<Project[]>([]),
    [current, setCurrent] = useState(""),
    [docs, setDocs] = useState<Doc[]>([]),
    [runs, setRuns] = useState<Run[]>([]),
    [docId, setDocId] = useState(""),
    [selectedRunId, setSelectedRunId] = useState(""),
    [attemptFailure, setAttemptFailure] = useState<{
      projectId: string;
      run: Run;
    } | null>(null),
    [drafts, setDrafts] = useState<Record<string, Draft>>({}),
    [search, setSearch] = useState("");
  const [modal, setModal] = useState(""),
    [form, setForm] = useState({ ...blank }),
    [busy, setBusy] = useState(""),
    [action, setAction] = useState(false),
    [error, setError] = useState(""),
    [toast, setToast] = useState(""),
    [drawer, setDrawer] = useState(false),
    [mobile, setMobile] = useState(false),
    [editing, setEditing] = useState(false),
    [editBody, setEditBody] = useState(""),
    [settings, setSettings] = useState({
      hasKey: false,
      hasModel: false,
      model: "",
      protected: false,
    }),
    [connection, setConnection] = useState(""),
    [loading, setLoading] = useState(false);
  const project = projects.find((p) => p.id === current),
    doc = docs.find((d) => d.id === docId),
    draft = drafts[current] || newDraft();
  const visibleRun =
    attemptFailure?.projectId === current
      ? attemptFailure.run
      : runs.find((r) => r.id === selectedRunId) || runs[0];
  const fileRef = useRef<HTMLInputElement>(null);
  const active = useRef(current);
  active.current = current;
  const loadedAuth = useRef(false);
  const generating = useRef(false);
  function patchDraft(p: Partial<Draft>) {
    setDrafts((old) => ({
      ...old,
      [current]: { ...(old[current] || newDraft()), ...p },
    }));
  }
  async function loadProjects(select?: string) {
    const list: Project[] = await api("projects");
    setProjects(list);
    setCurrent(
      (old) =>
        select || (list.some((p) => p.id === old) ? old : list[0]?.id || ""),
    );
  }
  async function loadRecords(id: string, select?: string) {
    const [ds, rs] = await Promise.all([
      api(`projects/${id}/documents`),
      api(`projects/${id}/runs`),
    ]);
    if (active.current !== id) return;
    setDocs(ds);
    setRuns(rs);
    setDocId(selectResultDocument(ds, rs, select));
    setSelectedRunId(rs[0]?.id || "");
  }
  async function refreshSettings() {
    setSettings(await api("settings"));
  }
  useEffect(() => {
    api("session")
      .then((s) => {
        setAuth(s.authenticated);
        setReady(true);
      })
      .catch((e) => {
        setError(e.message);
        setReady(true);
      });
  }, []);
  useEffect(() => {
    if (!auth || loadedAuth.current) return;
    loadedAuth.current = true;
    Promise.all([loadProjects(), refreshSettings()]).catch((e) =>
      setError(e.message),
    );
  }, [auth]);
  useEffect(() => {
    setDocs([]);
    setRuns([]);
    setDocId("");
    setEditing(false);
    setDrawer(false);
    if (current) {
      setLoading(true);
      loadRecords(current)
        .catch((e) => setError(e.message))
        .finally(() => {
          if (active.current === current) setLoading(false);
        });
    }
  }, [current]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 3500);
    return () => clearTimeout(t);
  }, [toast]);
  function changeProject(id: string) {
    if (editing && !confirm("正文修改尚未保存，确定切换项目？")) return;
    setCurrent(id);
    setMobile(false);
    setError("");
  }
  async function perform(fn: () => Promise<void>) {
    if (action) return;
    setAction(true);
    setError("");
    try {
      await fn();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setAction(false);
    }
  }
  async function login(e: React.FormEvent) {
    e.preventDefault();
    await perform(async () => {
      await api("session", "POST", { password });
      setPassword("");
      setAuth(true);
    });
  }
  function openProject(edit = false) {
    setForm(
      edit && project
        ? {
            name: project.name,
            business: project.business,
            users: project.users,
            stage: project.stage,
            scope: project.scope,
            constraints: project.constraints,
            unknowns: project.unknowns,
          }
        : { ...blank },
    );
    setModal(edit ? "edit" : "create");
  }
  async function saveProject(e: React.FormEvent) {
    e.preventDefault();
    await perform(async () => {
      const p = await api(
        modal === "edit" ? `projects/${current}` : "projects",
        modal === "edit" ? "PUT" : "POST",
        form,
      );
      await loadProjects(p.id);
      setModal("");
      setToast("项目已保存");
    });
  }
  async function generate() {
    if (generating.current || editing) return;
    if (!draft.task.trim()) {
      setError("请先描述当前业务任务");
      return;
    }
    generating.current = true;
    const id = current;
    const frozen = { ...draft };
    setBusy(id);
    setAttemptFailure(null);
    setDocId("");
    setError("");
    setEditing(false);
    try {
      const r = await api(`projects/${id}/generate`, "POST", {
        ...frozen,
        previousQuestions: frozen.questions,
      });
      if (active.current === id) {
        if (r.status === "needs_input") {
          patchDraft({ questions: r.questions });
          setToast("需要你补充关键信息");
        } else {
          patchDraft({ questions: [], clarification: "" });
          setDocId(r.document.id);
          setToast("分析已生成并自动保存");
        }
      }
      await loadRecords(id, r.document?.id);
      if (active.current === id)
        requestAnimationFrame(() =>
          document
            .getElementById(r.document ? "result" : "task")
            ?.scrollIntoView({ behavior: "smooth", block: "start" }),
        );
    } catch (e) {
      if (active.current === id) {
        setError((e as Error).message);
        setAttemptFailure({
          projectId: id,
          run: {
            id: "local-attempt",
            task: frozen.task,
            sources: frozen.sources,
            clarification: frozen.clarification,
            status: "failed",
            error: (e as Error).message,
            createdAt: new Date().toISOString(),
          },
        });
      }
      await loadRecords(id, "").catch(() => {});
      if (active.current === id)
        requestAnimationFrame(() =>
          document
            .getElementById("result")
            ?.scrollIntoView({ behavior: "smooth", block: "start" }),
        );
    } finally {
      generating.current = false;
      setBusy("");
    }
  }
  async function cancel() {
    await perform(async () => {
      await api(`projects/${busy}/cancel`, "POST", {});
      setToast("已发送取消请求，正在结束任务");
    });
  }
  const closeModal = useCallback(() => setModal(""), []);
  if (!ready)
    return (
      <main className="login">
        <div className="spinner" />
        正在打开工作台…
      </main>
    );
  if (!auth)
    return (
      <main className="login">
        <form className="login-card" onSubmit={login}>
          <div className="brand-symbol">
            <Icon name="spark" />
          </div>
          <span className="eyebrow">LEXIE WORKSPACE</span>
          <h1>AI产品经理助理工作台</h1>
          <p>把产品想法，整理成可评审的需求。</p>
          <label>
            访问口令
            <input
              autoFocus
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
              placeholder="输入你配置的访问口令"
            />
          </label>
          {error && (
            <div className="notice error" role="alert">
              {error}
            </div>
          )}
          <button className="primary" disabled={action}>
            进入工作台 <Icon name="arrow" />
          </button>
          <small>
            首次启动请先按 README 设置 APP_PASSWORD。口令在服务端配置，不是
            DeepSeek 密钥。
          </small>
        </form>
      </main>
    );
  return (
    <div className="app-shell">
      {mobile && (
        <button
          className="sidebar-scrim"
          aria-label="收起项目列表"
          onClick={() => setMobile(false)}
        />
      )}
      <aside className={"sidebar " + (mobile ? "open" : "")}>
        <div className="brand">
          <div className="brand-symbol">
            <Icon name="spark" />
          </div>
          <div>
            <strong>AI产品经理助理工作台</strong>
            <span>LEXIE · WORKSPACE</span>
          </div>
        </div>
        <button className="new-project" onClick={() => openProject()}>
          <Icon name="plus" />
          新建项目
        </button>
        <label className="search">
          <Icon name="search" />
          <input
            aria-label="搜索项目或任务"
            placeholder="搜索项目或任务"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </label>
        <div className="nav-label">
          我的项目 <span>{projects.length.toString().padStart(2, "0")}</span>
        </div>
        <nav className="project-list" aria-label="项目列表">
          {projects
            .filter(
              (p) =>
                p.name.includes(search) ||
                (p.id === current && runs.some((r) => r.task.includes(search))),
            )
            .map((p) => (
              <button
                className={
                  "project-item " + (p.id === current ? "selected" : "")
                }
                key={p.id}
                onClick={() => changeProject(p.id)}
              >
                <Icon name="folder" />
                <span>{p.name}</span>
                <i />
              </button>
            ))}
          {!projects.length && <p className="muted">从一个新项目开始。</p>}
        </nav>
        <div className="nav-label history-label">最近任务</div>
        <nav className="history" aria-label="历史任务">
          {runs
            .filter((r) => r.task.includes(search))
            .slice(0, 12)
            .map((r) => (
              <button
                key={r.id}
                onClick={() => {
                  if (editing && !confirm("放弃尚未保存的正文修改？")) return;
                  patchDraft({
                    task: r.task,
                    sources: r.sources || "",
                    clarification: r.clarification || "",
                    questions: r.questions || [],
                  });
                  setDocId(r.documentId || "");
                  setAttemptFailure(null);
                  setSelectedRunId(r.id);
                  setEditing(false);
                  setMobile(false);
                  if (r.error) setError(r.error);
                }}
              >
                <span className={"status-dot " + r.status} />
                <span>
                  <strong>{r.task.slice(0, 28)}</strong>
                  <small>
                    {runLabels[r.status]} · {fmt(r.createdAt)}
                  </small>
                </span>
              </button>
            ))}
          {!runs.length && <p className="muted">分析任务将记录在这里</p>}
        </nav>
        <div className="sidebar-bottom">
          <button
            onClick={() => {
              setModal("settings");
              refreshSettings().catch((e) => setError(e.message));
            }}
          >
            <Icon name="settings" />
            连接设置
          </button>
          <button onClick={() => setModal("help")}>
            <Icon name="book" />
            帮助与数据备份
          </button>
          <div className="profile">
            <span>L</span>
            <div>
              <strong>Lexie 的工作台</strong>
              <small>个人使用 · 需求分析 V1.1</small>
            </div>
          </div>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="icon-btn mobile-menu"
              aria-label="展开项目列表"
              onClick={() => setMobile(true)}
            >
              <Icon name="menu" />
            </button>
            <span>工作空间</span>
            <span className="slash">/</span>
            <strong>{project?.name || "未选择项目"}</strong>
          </div>
          <div className="header-actions">
            <button
              className={
                "connection " +
                (settings.hasKey && settings.hasModel ? "configured" : "")
              }
              onClick={() => setModal("settings")}
            >
              <span />
              {connection === "已连接"
                ? "已连接"
                : settings.hasKey && settings.hasModel
                  ? "已配置 · 待测试"
                  : "未配置模型"}
            </button>
            <button
              className="icon-btn"
              aria-label="帮助中心"
              onClick={() => setModal("help")}
            >
              <Icon name="book" />
            </button>
          </div>
        </header>
        <main className="workspace">
          <section className="page-heading">
            <div>
              <span className="eyebrow">YOUR PRODUCT THINKING, ORGANIZED</span>
              <h1>把产品想法，变成可评审的需求</h1>
              <p>
                输入想法和资料，生成用户场景、功能优先级、业务流程与验收标准。
              </p>
            </div>
            <div className="edition">
              工作台 <strong>01</strong>
              <span>需求分析</span>
            </div>
          </section>
          <section className="purpose-panel" aria-label="工作台能做什么">
            <div>
              <span className="subtle-badge purple">当前可用：需求分析</span>
              <h2>你提供背景，助理帮你整理需求</h2>
              <p>
                例如：“我想做手串电商客服” →
                用户与场景、MVP范围、异常处理、验收标准 → 编辑、保存和导出。
              </p>
            </div>
            <ol>
              <li>
                <b>1</b>
                <span>
                  建立项目<small>填写给谁用、要解决什么问题</small>
                </span>
              </li>
              <li>
                <b>2</b>
                <span>
                  提交分析<small>根据当前任务真实调用模型</small>
                </span>
              </li>
              <li>
                <b>3</b>
                <span>
                  审阅文档<small>核实内容，修改后保留版本</small>
                </span>
              </li>
            </ol>
            <p className="scope-note">
              本版暂不支持 AI 方案设计、PRD、竞品分析、自动联网或开发产品。
            </p>
          </section>
          {error && (
            <div className="notice error" role="alert">
              <div>
                <strong>操作未完成</strong>
                <p>{error}</p>
              </div>
              <button onClick={() => setError("")} aria-label="关闭错误提示">
                <Icon name="close" />
              </button>
            </div>
          )}
          {!project ? (
            <section className="panel empty">
              <Icon name="folder" />
              <h2>让第一个项目有个开始</h2>
              <p>建立项目背景，让每一次分析都有依据。</p>
              <button className="primary" onClick={() => openProject()}>
                新建项目
              </button>
              <button
                className="text-btn"
                disabled={action}
                onClick={() =>
                  perform(async () => {
                    const p = await api("demo", "POST", {});
                    await loadProjects(p.id);
                  })
                }
              >
                载入模拟示例
              </button>
            </section>
          ) : (
            <>
              <section className="context panel">
                <div className="section-heading">
                  <div className="section-title">
                    <Icon name="folder" />
                    <h2>项目背景</h2>
                    <span className="subtle-badge">
                      {project.stage || "未设置阶段"}
                    </span>
                  </div>
                  <button
                    className="text-btn"
                    onClick={() => openProject(true)}
                  >
                    编辑背景 <span>↗</span>
                  </button>
                </div>
                <div className="context-grid">
                  <div>
                    <span>业务对象</span>
                    <p>{project.business || "尚未填写"}</p>
                  </div>
                  <div>
                    <span>目标用户</span>
                    <p>{project.users || "尚未填写"}</p>
                  </div>
                  <div>
                    <span>已确认范围</span>
                    <p>{project.scope || "尚未填写"}</p>
                  </div>
                  <div>
                    <span>关键约束</span>
                    <p>{project.constraints || "尚未填写"}</p>
                  </div>
                </div>
                {project.unknowns && (
                  <div className="unknowns">
                    <span>待确认</span>
                    {project.unknowns}
                  </div>
                )}
              </section>
              <section className="panel task-panel">
                <div className="section-heading">
                  <div className="section-title">
                    <span className="number-label">01</span>
                    <h2>描述这次需求</h2>
                  </div>
                  <span className="subtle-badge purple">需求分析</span>
                </div>
                <p className="section-description">
                  说清想解决的问题，以及你已经知道的情况。信息不完整也可以开始。
                </p>
                <label className="sr-only" htmlFor="task">
                  本次业务任务
                </label>
                <textarea
                  id="task"
                  className="task-input"
                  placeholder="例如：我想为水晶手串电商做一个 AI 客服，先解决商品咨询和订单查询。请帮我明确第一版范围、异常处理和验收标准……"
                  value={draft.task}
                  maxLength={20000}
                  disabled={!!busy}
                  onChange={(e) =>
                    patchDraft({
                      task: e.target.value,
                      questions: [],
                      clarification: "",
                    })
                  }
                />
                <div className="input-meta">
                  <span>从一个示例开始</span>
                  <span>{draft.task.length.toLocaleString()} / 20,000 字</span>
                </div>
                <div className="example-row">
                  {examples.map((ex) => (
                    <button
                      key={ex.name}
                      disabled={!!busy}
                      onClick={() =>
                        patchDraft({
                          task: ex.text,
                          questions: [],
                          clarification: "",
                        })
                      }
                    >
                      {ex.name}
                      <span>↗</span>
                    </button>
                  ))}
                </div>
                <details className="sources">
                  <summary>
                    添加参考资料{" "}
                    <span>可选 · 粘贴访谈、业务说明或已有需求</span>
                  </summary>
                  <label className="sr-only" htmlFor="sources">
                    参考资料
                  </label>
                  <textarea
                    id="sources"
                    value={draft.sources}
                    onChange={(e) => patchDraft({ sources: e.target.value })}
                    maxLength={50000}
                    disabled={!!busy}
                    placeholder="请标注来源，例如【访谈记录 1】。只粘贴链接不会自动读取网页。"
                  />
                  <small>
                    {draft.sources.length.toLocaleString()} / 50,000 字 ·
                    本版本不自动访问网页或上传附件。
                  </small>
                </details>
                {draft.questions.length > 0 && (
                  <div className="questions">
                    <strong>还需要你确认</strong>
                    <ol>
                      {draft.questions.map((q) => (
                        <li key={q}>{q}</li>
                      ))}
                    </ol>
                    <label>
                      补充信息
                      <textarea
                        value={draft.clarification}
                        onChange={(e) =>
                          patchDraft({ clarification: e.target.value })
                        }
                        maxLength={10000}
                        disabled={!!busy}
                        placeholder="直接补充即可，无需重新输入整个任务"
                      />
                    </label>
                  </div>
                )}
                {editing && (
                  <p className="notice warning">
                    你正在编辑文档，请先保存或取消修改，再开始新的分析。
                  </p>
                )}
                <div className="task-footer">
                  <small>
                    <span className="lock-mark">◇</span>{" "}
                    请勿输入未经授权的个人信息、商业秘密或生产凭证。
                  </small>
                  <div>
                    <button
                      className="text-btn"
                      disabled={!!busy}
                      onClick={() => patchDraft(newDraft())}
                    >
                      清空
                    </button>
                    <button
                      className="primary"
                      disabled={
                        editing ||
                        !!busy ||
                        action ||
                        (!!draft.questions.length &&
                          !draft.clarification.trim())
                      }
                      onClick={generate}
                    >
                      {busy === current ? (
                        <>
                          <span className="spinner" />
                          正在生成
                        </>
                      ) : (
                        <>
                          开始分析 <Icon name="arrow" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
                {busy && (
                  <div className="running" role="status">
                    <span className="spinner" />
                    <div>
                      <strong>
                        {busy === current
                          ? "正在请求模型并生成需求分析"
                          : "另一个项目正在分析"}
                      </strong>
                      <small>
                        结果返回后检查格式与引用完整性，随后自动保存。最长等待约
                        120 秒。
                      </small>
                    </div>
                    <button
                      className="text-btn"
                      disabled={action}
                      onClick={cancel}
                    >
                      取消任务
                    </button>
                  </div>
                )}
              </section>
              <section className="result-section" id="result">
                <div className="result-heading">
                  <div className="section-title">
                    <Icon name="file" />
                    <h2>需求分析文档</h2>
                    <span className="count">{docs.length}</span>
                  </div>
                  {docs.length > 0 && (
                    <label className="version-select">
                      版本
                      <select
                        aria-label="选择文档版本"
                        value={docId}
                        onChange={(e) => {
                          if (editing && !confirm("放弃尚未保存的正文修改？"))
                            return;
                          setDocId(e.target.value);
                          setEditing(false);
                        }}
                      >
                        <option value="">本次任务状态 / 暂无新文档</option>
                        {docs.map((d) => (
                          <option key={d.id} value={d.id}>
                            v{d.version} ·{" "}
                            {d.demo
                              ? "演示"
                              : d.edited
                                ? "人工修订"
                                : "AI 生成"}{" "}
                            · {fmt(d.createdAt)}
                          </option>
                        ))}
                      </select>
                    </label>
                  )}
                </div>
                {loading ? (
                  <div className="panel empty">
                    <span className="spinner" />
                    正在读取文档…
                  </div>
                ) : busy === current ? (
                  <div className="panel empty" role="status">
                    <span className="spinner" />
                    <h3>正在生成本次分析</h3>
                    <p>旧文档保留在版本列表中，不会冒充本次结果。</p>
                  </div>
                ) : doc ? (
                  <article className="document panel">
                    <div className="doc-meta">
                      <span className="subtle-badge purple">
                        需求分析 · v{doc.version}
                      </span>
                      <span>{fmt(doc.createdAt)}</span>
                      <span>文档编号 {doc.id.slice(0, 8)}</span>
                      <span>
                        {doc.edited
                          ? "人工修订"
                          : doc.demo
                            ? "模拟示例"
                            : "模型生成"}
                      </span>
                      <button
                        className="text-btn"
                        onClick={() => setDrawer(true)}
                      >
                        查看依据 <span>↗</span>
                      </button>
                    </div>
                    {!doc.demo && (
                      <div className="notice success">
                        <strong>
                          {doc.edited ? "人工修订文档" : "本次模型生成已完成"}
                        </strong>
                        <span>
                          {" "}
                          · v{doc.version} · {doc.model || "保留原始来源"} ·{" "}
                          {fmt(doc.createdAt)}
                        </span>
                        <p>任务：{doc.task}</p>
                      </div>
                    )}
                    {doc.demo && (
                      <div className="notice demo">
                        你正在查看预置示例，不是本次分析结果。真实生成会创建新版本；失败原因会在任务状态中显示。
                      </div>
                    )}
                    {doc.warnings?.map((w) => (
                      <div className="notice warning" key={w}>
                        {w}
                      </div>
                    ))}
                    {editing ? (
                      <>
                        <label className="edit-label">
                          编辑 Markdown 正文 · 保存后创建新版本
                        </label>
                        <textarea
                          className="document-editor"
                          value={editBody}
                          onChange={(e) => setEditBody(e.target.value)}
                          maxLength={120000}
                        />
                        <div className="edit-actions">
                          <button
                            className="secondary"
                            onClick={() => setEditing(false)}
                          >
                            取消修改
                          </button>
                          <button
                            className="primary"
                            disabled={action}
                            onClick={() =>
                              perform(async () => {
                                const n = await api(
                                  `projects/${current}/documents/${doc.id}`,
                                  "PUT",
                                  { body: editBody },
                                );
                                await loadRecords(current, n.id);
                                setEditing(false);
                                setToast("已另存为新版本");
                              })
                            }
                          >
                            保存为新版本
                          </button>
                        </div>
                      </>
                    ) : (
                      <div className="markdown">
                        <ReactMarkdown
                          remarkPlugins={[remarkGfm]}
                          components={{
                            img: () => null,
                            a: ({ href, children }) => (
                              <a
                                href={href}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                {children}
                              </a>
                            ),
                          }}
                        >
                          {doc.body}
                        </ReactMarkdown>
                      </div>
                    )}
                    <div className="document-toolbar">
                      <div>
                        <button
                          className="secondary"
                          onClick={() =>
                            perform(async () => {
                              await navigator.clipboard.writeText(doc.body);
                              setToast("全文已复制");
                            })
                          }
                        >
                          <Icon name="copy" />
                          复制全文
                        </button>
                        <button
                          className="secondary"
                          onClick={() => {
                            setEditBody(doc.body);
                            setEditing(true);
                          }}
                        >
                          继续编辑
                        </button>
                        <button
                          className="secondary"
                          onClick={() =>
                            download(
                              `${project.name}-需求分析-v${doc.version}.md`,
                              doc.body,
                            )
                          }
                        >
                          <Icon name="download" />
                          导出
                        </button>
                      </div>
                      <div>
                        <button
                          className="text-btn"
                          disabled={!!busy}
                          onClick={() => {
                            patchDraft({
                              task: doc.task,
                              sources: doc.sources || "",
                              clarification: doc.clarification || "",
                              questions: [],
                            });
                            document.getElementById("task")?.focus();
                            setToast(
                              "原任务已填入，点击开始分析将重新调用模型",
                            );
                          }}
                        >
                          重新生成
                        </button>
                        <button
                          className="text-btn danger"
                          disabled={action}
                          onClick={() => {
                            if (
                              confirm(
                                `确定删除 v${doc.version}？删除后不可撤销。`,
                              )
                            )
                              perform(async () => {
                                await api(
                                  `projects/${current}/documents/${doc.id}`,
                                  "DELETE",
                                );
                                await loadRecords(current);
                                setToast("版本已删除");
                              });
                          }}
                        >
                          删除版本
                        </button>
                      </div>
                    </div>
                    <div className="saved-line">
                      <span>
                        <Icon name="check" />
                        已保存到项目 · {project.name}
                      </span>
                      {doc.usage && (
                        <span>
                          {doc.usage.total_tokens.toLocaleString()} Tokens ·{" "}
                          {Math.round((doc.elapsed || 0) / 1000)} 秒 ·{" "}
                          {doc.model}
                        </span>
                      )}
                    </div>
                  </article>
                ) : visibleRun ? (
                  <div
                    className={"panel task-outcome " + visibleRun.status}
                    role="status"
                  >
                    <span className="subtle-badge">
                      本次任务 ·{" "}
                      {runLabels[visibleRun.status] || visibleRun.status}
                    </span>
                    <h3>
                      {visibleRun.status === "needs_input"
                        ? "请先补充信息，再继续分析"
                        : visibleRun.status === "completed"
                          ? "该任务文档已删除"
                          : visibleRun.status === "running"
                            ? "任务仍在服务端运行"
                            : "本次没有生成新文档"}
                    </h3>
                    <p>
                      {visibleRun.error ||
                        (visibleRun.status === "needs_input"
                          ? "问题已显示在任务输入区。原输入保留，无需重填。"
                          : "可以从版本列表查看以前的文档。")}
                    </p>
                    <p className="outcome-task">任务：{visibleRun.task}</p>
                    <div>
                      <button
                        className="primary"
                        disabled={!!busy}
                        onClick={() => {
                          patchDraft({
                            task: visibleRun.task,
                            sources: visibleRun.sources || "",
                            clarification: visibleRun.clarification || "",
                            questions: visibleRun.questions || [],
                          });
                          document.getElementById("task")?.focus();
                        }}
                      >
                        返回任务，修改后重试
                      </button>
                      <button
                        className="secondary"
                        onClick={() => setModal("settings")}
                      >
                        检查连接
                      </button>
                    </div>
                    <small>旧文档没有被覆盖，也不会替代这次失败的结果。</small>
                  </div>
                ) : (
                  <div className="panel empty result-empty">
                    <div className="empty-icon">
                      <Icon name="file" />
                    </div>
                    <h3>下一份清晰的需求，从这里开始</h3>
                    <p>输入任务并开始分析，结果将自动保存到当前项目。</p>
                    <span>执行摘要 · MVP 范围 · 业务流程 · 验收标准</span>
                  </div>
                )}
              </section>
            </>
          )}
          <footer className="page-footer">
            <span>LEXIE · AI PRODUCT ASSISTANT</span>
            <span>让判断有依据，让想法可执行。</span>
          </footer>
        </main>
      </div>
      {toast && (
        <div className="toast" role="status">
          <Icon name="check" />
          {toast}
        </div>
      )}
      {drawer && doc && (
        <div className="drawer-overlay">
          <button
            className="drawer-backdrop"
            aria-label="关闭依据面板"
            onClick={() => setDrawer(false)}
          />
          <aside
            className="drawer"
            role="dialog"
            aria-modal="true"
            aria-label="依据与假设"
          >
            <div className="modal-head">
              <div>
                <span className="eyebrow">DOCUMENT CONTEXT</span>
                <h2>依据与假设</h2>
              </div>
              <button
                className="icon-btn"
                onClick={() => setDrawer(false)}
                aria-label="关闭依据面板"
              >
                <Icon name="close" />
              </button>
            </div>
            <p className="section-description">
              以下为模型或示例的分类整理，不等于独立事实核验。外部资料未自动检索。
            </p>
            {Object.entries(evidenceLabels).map(([key, label]) => (
              <section className="evidence-section" key={key}>
                <h3>{label}</h3>
                {Array.isArray(doc.evidence?.[key]) &&
                doc.evidence[key].length ? (
                  <ul>
                    {doc.evidence[key].map((v, i) => (
                      <li key={i}>{v}</li>
                    ))}
                  </ul>
                ) : (
                  <p>暂无记录，请人工补充。</p>
                )}
              </section>
            ))}
            <details className="snapshot">
              <summary>查看本次输入与项目快照</summary>
              <h4>任务输入</h4>
              <p>{doc.task}</p>
              <h4>参考资料</h4>
              <p>{doc.sources || "未提供"}</p>
              {doc.clarification && (
                <>
                  <h4>补充回答</h4>
                  <p>{doc.clarification}</p>
                </>
              )}
              {Object.entries(labels).map(([key, label]) => (
                <div key={key}>
                  <h4>{label}</h4>
                  <p>{doc.snapshot?.[key as keyof Project] || "未填写"}</p>
                </div>
              ))}
            </details>
          </aside>
        </div>
      )}
      {(modal === "create" || modal === "edit") && (
        <Modal
          title={modal === "create" ? "新建项目" : "编辑项目背景"}
          close={closeModal}
        >
          <form onSubmit={saveProject}>
            <p className="section-description">
              背景会随每次任务一起发送给模型。先填你知道的，其他可以稍后补充。
            </p>
            <div className="project-form">
              {Object.entries(labels).map(([k, label]) => (
                <label key={k}>
                  {label}
                  {k === "name" && <span className="required"> *</span>}
                  {k === "name" || k === "stage" ? (
                    <input
                      required={k === "name"}
                      value={form[k as keyof typeof blank]}
                      maxLength={k === "name" ? 100 : 6000}
                      onChange={(e) =>
                        setForm((f) => ({ ...f, [k]: e.target.value }))
                      }
                    />
                  ) : (
                    <textarea
                      rows={2}
                      value={form[k as keyof typeof blank]}
                      maxLength={6000}
                      onChange={(e) =>
                        setForm((f) => ({ ...f, [k]: e.target.value }))
                      }
                    />
                  )}
                </label>
              ))}
            </div>
            {error && <div className="notice error">{error}</div>}
            <div className="modal-actions">
              {modal === "edit" && (
                <button
                  type="button"
                  className="text-btn danger"
                  disabled={action || !!busy}
                  onClick={() => {
                    if (
                      confirm(
                        "删除项目会一并删除该项目的全部任务与文档，是否继续？",
                      )
                    )
                      perform(async () => {
                        await api(`projects/${current}`, "DELETE");
                        await loadProjects();
                        setModal("");
                        setToast("项目已删除");
                      });
                  }}
                >
                  删除项目
                </button>
              )}
              <button type="button" className="secondary" onClick={closeModal}>
                取消
              </button>
              <button className="primary" disabled={action}>
                保存项目
              </button>
            </div>
          </form>
        </Modal>
      )}
      {modal === "settings" && (
        <Modal title="连接设置" close={closeModal}>
          <div className="settings-status">
            <span
              className={
                "status-dot " +
                (settings.hasKey && settings.hasModel ? "completed" : "failed")
              }
            />
            <strong>
              {connection ||
                (settings.hasKey && settings.hasModel
                  ? "已配置 · 尚未测试"
                  : "未配置")}
            </strong>
          </div>
          <p>模型：{settings.model || "尚未填写模型名称"}</p>
          <p className="section-description">
            密钥只保存在服务端，不在网页中填写或回显。配置后需重启应用。
          </p>
          <ol className="help-list">
            <li>
              本地：将根目录的 <code>.env.example</code> 复制为{" "}
              <code>.env.local</code>。
            </li>
            <li>
              填写 <code>DEEPSEEK_API_KEY</code>、<code>DEEPSEEK_MODEL</code> 和{" "}
              <code>APP_PASSWORD</code>。模型名称以服务商当前控制台为准。
            </li>
            <li>
              在线：在部署平台设置同名环境变量，并挂载持久化磁盘保存数据。
            </li>
          </ol>
          <div className="notice warning">
            连接测试会发起一次真实的小额模型调用。请勿将 .env.local 上传到
            GitHub。
          </div>
          {error && <div className="notice error">{error}</div>}
          <div className="modal-actions">
            <button
              className="secondary"
              disabled={action}
              onClick={() =>
                perform(async () => {
                  await refreshSettings();
                  setConnection("");
                })
              }
            >
              刷新配置状态
            </button>
            <button
              className="primary"
              disabled={action}
              onClick={() =>
                perform(async () => {
                  setConnection("正在连接");
                  try {
                    await api("settings", "POST", {});
                    setConnection("已连接");
                    setToast("模型连接测试成功");
                  } catch (e) {
                    setConnection("连接失败");
                    throw e;
                  }
                })
              }
            >
              测试连接
            </button>
          </div>
        </Modal>
      )}
      {modal === "help" && (
        <Modal title="帮助与数据备份" close={closeModal}>
          <div className="help-content">
            <h3>如何开始</h3>
            <p>
              新建项目并填写背景，选择示例或描述任务，再点击“开始分析”。如有关键追问，在原任务下补充即可继续。
            </p>
            <h3>结果如何保存</h3>
            <p>
              成功生成的结果自动保存到当前项目。继续编辑会创建新版本；取消修改保留原文。可复制正文或导出
              Markdown。
            </p>
            <h3>演示和真实结果</h3>
            <p>
              预置项目和示例文档是模拟内容。点击开始分析才会真实调用模型，失败不会用演示结果替代。AI
              输出仍需人工检查。
            </p>
            <h3>隐私与使用边界</h3>
            <p>
              项目、任务与参考资料会发送给配置的模型服务商。仅输入有权使用的资料，避免个人敏感信息、商业秘密和生产凭证。备份文件也包含项目资料，请妥善保管。
            </p>
            <h3>备份与恢复</h3>
            <p>
              备份包含全部项目和文档版本，不包含 API
              密钥，也不包含运行日志。恢复会创建带“导入”后缀的副本，不覆盖现有项目。在线版需持久化磁盘，否则重部署可能丢失数据。
            </p>
            <div className="backup-actions">
              <button
                className="secondary"
                onClick={() =>
                  perform(async () =>
                    download(
                      "AI-PM-项目备份.json",
                      JSON.stringify(await api("backup"), null, 2),
                      "application/json",
                    ),
                  )
                }
              >
                <Icon name="download" />
                导出全部项目
              </button>
              <button
                className="secondary"
                onClick={() => fileRef.current?.click()}
                disabled={action || !!busy}
              >
                导入备份副本
              </button>
              <input
                ref={fileRef}
                className="sr-only"
                type="file"
                accept=".json,application/json"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  if (f.size > 2000000) {
                    setError("备份文件不能超过 2 MB");
                    e.target.value = "";
                    return;
                  }
                  if (confirm("将备份作为新项目副本导入，是否继续？"))
                    perform(async () => {
                      const data = JSON.parse(await f.text());
                      const r = await api("restore", "POST", data);
                      await loadProjects();
                      setToast(`已导入 ${r.count} 个项目副本`);
                    });
                  e.target.value = "";
                }}
              />
            </div>
            {error && <div className="notice error">{error}</div>}
            <h3>退出访问</h3>
            <p>会话有效期为 8 小时。公共设备使用后请退出。</p>
            <button
              className="text-btn danger"
              onClick={() =>
                perform(async () => {
                  await api("session", "DELETE");
                  loadedAuth.current = false;
                  setAuth(false);
                  setModal("");
                  setProjects([]);
                  setDocs([]);
                  setRuns([]);
                  setDrafts({});
                })
              }
            >
              退出工作台
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
