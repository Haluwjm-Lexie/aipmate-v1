import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
process.env.DATA_DIR = mkdtempSync(join(tmpdir(), "aipm-api-"));
process.env.NODE_ENV = "production";
process.env.APP_PASSWORD = "test-only-pass";
const { handle } = await import("../lib/api.mjs");
let cookie = "";
async function request(path, method = "GET", body, options = {}) {
  const headers = {
    host: "app.test",
    origin: "https://app.test",
    ...options.headers,
  };
  if (cookie) headers.cookie = cookie;
  const r = await handle(
    new Request("https://app.test/api/" + path, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    }),
  );
  return {
    status: r.status,
    data: await r.json(),
    cookie: r.headers.get("set-cookie"),
  };
}
const good = {
  status: "completed",
  title: "测试需求分析",
  body:
    "# 测试需求分析\n\n## 用户与场景\n" +
    "业务流程和验收标准需要人工复核。".repeat(20),
  evidence: {
    facts: ["来自项目背景"],
    sources: [],
    suggestions: [],
    assumptions: [],
    risks: [],
  },
};
const response = (result, finish_reason = "stop") =>
  Response.json({
    choices: [{ finish_reason, message: { content: JSON.stringify(result) } }],
    usage: { total_tokens: 42 },
  });
test("authenticated API lifecycle, failures, clarification, duplicate prevention and cancellation", async () => {
  assert.equal((await request("projects")).status, 401);
  const login = await request("session", "POST", {
    password: "test-only-pass",
  });
  assert.equal(login.status, 200);
  cookie = login.cookie.split(";")[0];
  assert.equal(
    (
      await request(
        "projects",
        "POST",
        { name: "X" },
        { headers: { origin: "https://evil.test" } },
      )
    ).status,
    403,
  );
  const p = (
    await request("projects", "POST", { name: "API 项目", users: "消费者" })
  ).data;
  const q = (await request("projects", "POST", { name: "第二项目" })).data;
  assert.equal(
    (
      await request(`projects/${p.id}`, "PUT", {
        name: "更新名称",
        business: "模拟业务",
      })
    ).data.name,
    "更新名称",
  );
  assert.equal(
    (await request(`projects/${p.id}/generate`, "POST", { task: "" })).status,
    400,
  );
  const before = (await request(`projects/${p.id}/documents`)).data.length;
  assert.equal(
    (await request(`projects/${p.id}/generate`, "POST", { task: "无密钥任务" }))
      .status,
    502,
  );
  assert.equal(
    (await request(`projects/${p.id}/documents`)).data.length,
    before,
  );
  process.env.DEEPSEEK_API_KEY = "test-only-not-a-real-key";
  process.env.DEEPSEEK_MODEL = "fixture-model";
  const originalFetch = globalThis.fetch;
  try {
    globalThis.fetch = async () =>
      response({ status: "needs_input", questions: ["服务的用户是谁？"] });
    const ask = await request(`projects/${p.id}/generate`, "POST", {
      task: "帮我分析业务",
    });
    assert.equal(ask.data.status, "needs_input");
    assert.equal(
      (await request(`projects/${p.id}/documents`)).data.length,
      before,
    );
    let sent;
    globalThis.fetch = async (_url, opts) => {
      sent = JSON.parse(opts.body);
      return response(good);
    };
    const done = await request(`projects/${p.id}/generate`, "POST", {
      task: "分析只读订单查询",
      sources: "用户访谈：需要查询本人订单",
      clarification: "消费者",
      previousQuestions: ask.data.questions,
    });
    assert.equal(done.status, 200);
    assert.equal(done.data.document.demo, false);
    assert.ok(sent.messages[1].content.includes("消费者"));
    const id = done.data.document.id;
    assert.equal(
      (
        await request(`projects/${q.id}/documents/${id}`, "PUT", {
          body: "越权",
        })
      ).status,
      404,
    );
    const edit = await request(`projects/${p.id}/documents/${id}`, "PUT", {
      body: "# 修改后正文",
    });
    assert.equal(edit.data.version, 2);
    assert.equal((await request(`projects/${p.id}/documents`)).data.length, 2);
    globalThis.fetch = async () => response(good, "length");
    assert.equal(
      (await request(`projects/${p.id}/generate`, "POST", { task: "截断测试" }))
        .status,
      502,
    );
    globalThis.fetch = async () => new Response("", { status: 401 });
    const denied = await request(`projects/${p.id}/generate`, "POST", {
      task: "错误密钥",
    });
    assert.match(denied.data.error, /密钥无效/);
    globalThis.fetch = async () => response({ status: "completed", body: "" });
    assert.equal(
      (await request(`projects/${p.id}/generate`, "POST", { task: "空内容" }))
        .status,
      502,
    );
    let started;
    const upstreamStarted = new Promise((r) => (started = r));
    globalThis.fetch = async (_url, opts) =>
      new Promise((_resolve, reject) => {
        started();
        opts.signal.addEventListener(
          "abort",
          () => reject(new DOMException("aborted", "AbortError")),
          { once: true },
        );
      });
    const pending = request(`projects/${p.id}/generate`, "POST", {
      task: "取消测试",
    });
    await upstreamStarted;
    assert.equal(
      (await request(`projects/${p.id}/generate`, "POST", { task: "重复测试" }))
        .status,
      409,
    );
    assert.equal((await request(`projects/${p.id}`, "DELETE", {})).status, 409);
    await request(`projects/${p.id}/cancel`, "POST", {});
    assert.equal((await pending).status, 409);
    const runs = (await request(`projects/${p.id}/runs`)).data;
    assert.equal(runs[0].status, "cancelled");
    assert.equal((await request(`projects/${p.id}/documents`)).data.length, 2);
    const backup = (await request("backup")).data;
    assert.ok(!JSON.stringify(backup).includes("test-only-not-a-real-key"));
    assert.equal((await request("restore", "POST", backup)).status, 200);
    await request(`projects/${p.id}/documents/${id}`, "DELETE", {});
    assert.equal((await request(`projects/${p.id}/documents`)).data.length, 1);
    assert.equal((await request(`projects/${p.id}`, "DELETE", {})).status, 200);
    const prev = process.env.APP_PASSWORD;
    delete process.env.APP_PASSWORD;
    assert.equal((await request("projects")).status, 401);
    process.env.APP_PASSWORD = prev;
  } finally {
    globalThis.fetch = originalFetch;
    delete process.env.DEEPSEEK_API_KEY;
    delete process.env.DEEPSEEK_MODEL;
  }
});
